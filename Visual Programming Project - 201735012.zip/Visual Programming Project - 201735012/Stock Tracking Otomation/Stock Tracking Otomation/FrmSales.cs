﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stock_Tracking_Otomation
{
    public partial class FrmSales : Form
    {
        public FrmSales()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection("Data Source=DESKTOP-43Q01LI;Initial Catalog=Stock_Tracking;Integrated Security=True");
        DataSet daset = new DataSet();
        private void listBasket()
        {
            connection.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from Basket",connection);
            adtr.Fill(daset, "Basket");
            dataGridView1.DataSource = daset.Tables["Basket"];
            dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[1].Visible = false;
            dataGridView1.Columns[2].Visible = false;

            connection.Close();
        }
        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void FrmSales_Load(object sender, EventArgs e)
        {
            listBasket();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            FrmAddProduct add = new FrmAddProduct();
            add.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FrmAddCustomer add = new FrmAddCustomer();
            add.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FrmListCustomer listing = new FrmListCustomer();
            listing.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmCategory category = new FrmCategory();
            category.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmBrand brand = new FrmBrand();
            brand.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            FrmListProduct list = new FrmListProduct();
            list.ShowDialog();
        } 

        private void calculate ()
        {
            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand("select sum(TotalPrice) from Basket",connection);
                lblGrandTotal.Text = command.ExecuteScalar() + "$";
                connection.Close();

            }
            catch (Exception)
            {
                ;
            }
        }



        private void txtTC_TextChanged(object sender, EventArgs e)
        {
            if (txtTC.Text=="")
            {
                txtNameSurname.Text = "";
                txtTelephone.Text = "";
            }         
            
            connection.Open();
            SqlCommand command = new SqlCommand("select *from Customer where TC like '"+txtTC.Text+"'",connection);
            SqlDataReader read = command.ExecuteReader();
            while (read.Read())
            {
                txtNameSurname.Text = read["NameSurname"].ToString();
                txtTelephone.Text = read["Telephone"].ToString();

            }
            connection.Close();
        }

        private void txtBarcodeNo_TextChanged(object sender, EventArgs e)
        {
            if (txtBarcodeNo.Text == "")
            {
                foreach (Control item in groupBox2.Controls)
                {
                    if (item != txtQuantity)
                    {
                        item.Text = "";
                    }
                }
            }

            connection.Open();
            SqlCommand command = new SqlCommand("select *from Product where BarcodeNo like '" + txtBarcodeNo.Text + "'", connection);
            SqlDataReader read = command.ExecuteReader();
            while (read.Read())
            {
                txtProductName.Text = read["ProductName"].ToString();
                txtSalesPrice.Text = read["SalesPrice"].ToString();
            }
            connection.Close();
        }

        private void Clean()
        {
            if (txtBarcodeNo.Text == "")
            {
                foreach (Control item in groupBox2.Controls)
                {
                    if (item is TextBox)
                    {
                        if (item != txtQuantity)
                        {
                            item.Text = "";
                        }
                    }
                }
            }
        }

        private void FrmSales_Keydown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Multiply)
            {
                txtQuantity.Text = txtBarcodeNo.Text.Substring(txtBarcodeNo.Text.Length - 1);
                txtBarcodeNo.Text = "";
            }
        }




        bool instance;
        private void BarcodeControl()
        {
            instance = true;
            connection.Open();
            SqlCommand command = new SqlCommand("select *from Basket",connection);
            SqlDataReader read = command.ExecuteReader();
            while (read.Read())
            {
                if (txtBarcodeNo.Text==read["BarcodeNo"].ToString())
                {
                    instance = false;

                }
            }
            connection.Close();
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            BarcodeControl();
            if (instance==true)
            {
                connection.Open();
                SqlCommand command = new SqlCommand("insert into Basket(TC,NameSurname,Telephone,BarcodeNo,ProductName,Quantity,SalesPrice,TotalPrice,Date) values(@TC,@NameSurname,@Telephone,@BarcodeNo,@ProductName,@Quantity,@SalesPrice,@TotalPrice,@Date) ", connection);
                command.Parameters.AddWithValue("@TC", txtTC.Text);
                command.Parameters.AddWithValue("@NameSurname", txtNameSurname.Text);
                command.Parameters.AddWithValue("@Telephone", txtTelephone.Text);
                command.Parameters.AddWithValue("@BarcodeNo", txtBarcodeNo.Text);
                command.Parameters.AddWithValue("@ProductName", txtProductName.Text);
                command.Parameters.AddWithValue("@Quantity", int.Parse(txtQuantity.Text));
                command.Parameters.AddWithValue("@SalesPrice", double.Parse(txtSalesPrice.Text));
                command.Parameters.AddWithValue("@TotalPrice", double.Parse(txtTotalPrice.Text));
                command.Parameters.AddWithValue("@Date", DateTime.Now.ToString());
                command.ExecuteNonQuery();
                connection.Close();
            }
            else
            {
                connection.Open();
                SqlCommand command2 = new SqlCommand("update Basket Quantity=Quantity+'"+int.Parse(txtQuantity.Text)+ "'where BarcodeNo='" + txtBarcodeNo.Text + "' ", connection);
                command2.ExecuteNonQuery();

                SqlCommand command3 = new SqlCommand("update Basket TotalPrice=Quantity*SalesPrice where BarcodeNo='"+txtBarcodeNo.Text+"'" , connection);
                command3.ExecuteNonQuery();

                connection.Close();
            }

            txtQuantity.Text = "1";
            daset.Tables["Basket"].Clear();
            listBasket();
            calculate();
            foreach (Control item in groupBox2.Controls)
            {
                if (item is TextBox)
                {
                    if (item != txtQuantity)
                    {
                        item.Text = "";
                    }
                }
            }

        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            try
            {
                txtTotalPrice.Text = (double.Parse(txtQuantity.Text) * double.Parse(txtSalesPrice.Text)).ToString();
            }
            catch (Exception)
            {

                ;
            }
        }

        private void txtSalesPrice_TextChanged(object sender, EventArgs e)
        {
            try
            {
                txtTotalPrice.Text = (double.Parse(txtQuantity.Text) * double.Parse(txtSalesPrice.Text)).ToString();
            }
            catch (Exception)
            {

                ;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand command = new SqlCommand("delete from Basket where BarcodeNo='"+dataGridView1.CurrentRow.Cells["BarcodeNo"].Value.ToString()+"'",connection);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("The product removed from the Basket");
            daset.Tables["Basket"].Clear();
            listBasket();
            calculate();
        }

        private void btnSaleCancel_Click(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand command = new SqlCommand("delete from Basket ", connection);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("The products removed from the Basket");
            daset.Tables["Basket"].Clear();
            listBasket();
            calculate();
        }


        private void button9_Click(object sender, EventArgs e)
        {
            FrmListSales list = new FrmListSales();
            list.ShowDialog();
        }

        private void btnSales_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.Rows.Count-1; i++)
            {
                connection.Open();
                SqlCommand command = new SqlCommand("insert into Sales(TC,NameSurname,Telephone,BarcodeNo,ProductName,Quantity,SalesPrice,TotalPrice,Date) values(@TC,@NameSurname,@Telephone,@BarcodeNo,@ProductName,@Quantity,@SalesPrice,@TotalPrice,@Date) ", connection);
                command.Parameters.AddWithValue("@TC", txtTC.Text);
                command.Parameters.AddWithValue("@NameSurname", txtNameSurname.Text);
                command.Parameters.AddWithValue("@Telephone", txtTelephone.Text);
                command.Parameters.AddWithValue("@BarcodeNo", dataGridView1.Rows[i].Cells["BarcodeNo"].Value.ToString());
                command.Parameters.AddWithValue("@ProductName", dataGridView1.Rows[i].Cells["ProductName"].Value.ToString());
                command.Parameters.AddWithValue("@Quantity", int.Parse(dataGridView1.Rows[i].Cells["Quantity"].Value.ToString()));
                command.Parameters.AddWithValue("@SalesPrice", double.Parse(dataGridView1.Rows[i].Cells["SalesPrice"].Value?.ToString()));
                command.Parameters.AddWithValue("@TotalPrice", double.Parse(dataGridView1.Rows[i].Cells["TotalPrice"].Value?.ToString()));
                command.Parameters.AddWithValue("@Date", DateTime.Now.ToString());
                command.ExecuteNonQuery();
                SqlCommand command2 = new SqlCommand("update Product set Quantity = Quantity-'" + int.Parse(dataGridView1.Rows[i].Cells["Quantity"].Value.ToString()) + "' where BarcodeNo='" + dataGridView1.Rows[i].Cells["BarcodeNo"].Value.ToString() + "'", connection);
                command2.ExecuteNonQuery();
                connection.Close();

            }
            connection.Open();
            SqlCommand command3 = new SqlCommand("delete from Basket ", connection);
            command3.ExecuteNonQuery();
            connection.Close();
            daset.Tables["Basket"].Clear();
            listBasket();
            calculate();
        }
    }
}
