﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stock_Tracking_Otomation
{
    public partial class FrmAddProduct : Form
    {
        public FrmAddProduct()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection("Data Source=DESKTOP-43Q01LI;Initial Catalog=Stock_Tracking;Integrated Security=True");
        bool instance;
        private void Barcodecontrol()
        {
            instance = true;
            connection.Open();
            SqlCommand command = new SqlCommand("select *from Product", connection);
            SqlDataReader read = command.ExecuteReader();
            while (read.Read())
            {
                if (txtBarcodeNo.Text==read["BarcodeNo"].ToString() || txtBarcodeNo.Text=="")
                {
                    instance = false;
                }
            }
            connection.Close();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }


        private void Categorybring()
        {
            connection.Open();
            SqlCommand command = new SqlCommand("select *from CategoryInformations", connection);
            SqlDataReader read = command.ExecuteReader();
            while (read.Read())
            {
                comboCategory.Items.Add(read["Category"].ToString());
            }
            connection.Close();
        }

        private void FrmAddProduct_Load(object sender, EventArgs e)
        {
            Categorybring();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void comboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBrand.Items.Clear();
            comboBrand.Text = "";
            connection.Open();
            SqlCommand command = new SqlCommand("select *from BrandInformations where Category='" + comboCategory.SelectedItem + "'", connection);
            SqlDataReader read = command.ExecuteReader();
            while (read.Read())
            {
                comboBrand.Items.Add(read["Brand"].ToString());
            }
            connection.Close();
        }

        private void btnNewAdd_Click(object sender, EventArgs e)
        {
            Barcodecontrol();
            if (instance==true)
            {
                connection.Open();
                SqlCommand command = new SqlCommand("insert into Product(BarcodeNo,Category,Brand,ProductName,Quantity,PurchasePrice,SalesPrice,Date) values(@BarcodeNo,@Category,@Brand,@ProductName,@Quantity,@PurchasePrice,@SalesPrice,@Date)", connection);
                command.Parameters.AddWithValue("@BarcodeNo", txtBarcodeNo.Text);
                command.Parameters.AddWithValue("@Category", comboCategory.Text);
                command.Parameters.AddWithValue("@Brand", comboBrand.Text);
                command.Parameters.AddWithValue("@ProductName", txtProductName.Text);
                command.Parameters.AddWithValue("@Quantity", int.Parse(txtQuantity.Text));
                command.Parameters.AddWithValue("@PurchasePrice", double.Parse(txtPurchasePrice.Text));
                command.Parameters.AddWithValue("@SalesPrice", double.Parse(txtSalesPrice.Text));
                command.Parameters.AddWithValue("@Date", DateTime.Now.ToString());

                command.ExecuteNonQuery();
                connection.Close();
                MessageBox.Show("Added product");
            }
            else
            {
                MessageBox.Show("There is such a BarcodeNo","Warning");
            }



            comboBrand.Items.Clear();
            foreach (Control item in groupBox1.Controls)
            {
                if (item is TextBox)
                {
                    item.Text = "";
                }
                if (item is ComboBox)
                {
                    item.Text = "";
                }
            }
        }

        private void BarcodeNotxt_TextChanged(object sender, EventArgs e)
        {
            if (BarcodeNotxt.Text=="")
            {
                lblQuantity.Text = "";  
                foreach (Control item in groupBox2.Controls)
                {
                    if (item is TextBox)
                    {
                        item.Text = "";
                    }
                }
            }

            connection.Open();
            SqlCommand command = new SqlCommand("select *from product where BarcodeNo like '"+BarcodeNotxt.Text+"'",connection);
            SqlDataReader read = command.ExecuteReader();
            while (read.Read())
            {
                Categorytxt.Text = read["Category"].ToString();
                Brandtxt.Text = read["Brand"].ToString();
                ProductNametxt.Text = read["ProductName"].ToString();
                lblQuantity.Text = read["Quantity"].ToString();
                PurchasePricetxt.Text = read["PurchasePrice"].ToString();
                SalePricetxt.Text = read["SalePrice"].ToString();
            }
            connection.Close();
        }

        private void btnExistingAdd_Click(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand command = new SqlCommand("update Product set Quantity = Quantity+'"+int.Parse(Quantitytxt.Text)+"' where BarcodeNo='"+BarcodeNotxt.Text+"'",connection);
            command.ExecuteNonQuery();
            connection.Close();
            foreach (Control item in groupBox2.Controls)
            {
                if (item is TextBox)
                {
                    item.Text = "";
                }
            }
            MessageBox.Show("Added to the existing product");
        }
    }
}
