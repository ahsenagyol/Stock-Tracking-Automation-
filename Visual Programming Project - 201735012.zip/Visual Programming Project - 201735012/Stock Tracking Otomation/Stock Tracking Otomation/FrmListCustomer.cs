﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stock_Tracking_Otomation
{
    public partial class FrmListCustomer : Form
    {
        public FrmListCustomer()
        {
            InitializeComponent();
        }
        SqlConnection connection = new SqlConnection("Data Source=DESKTOP-43Q01LI;Initial Catalog=Stock_Tracking;Integrated Security=True");
        DataSet daset = new DataSet();
        private void FrmListingCustomer_Load(object sender, EventArgs e)
        {
            Show_Registry();
        }

        private void Show_Registry()
        {
            connection.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from Customer", connection);
            adtr.Fill(daset, "Customer");
            dataGridView1.DataSource = daset.Tables["customer"];
            connection.Close();
        }

        private void FrmListingCustomer_DoubleClick(object sender, EventArgs e)
        {
            txtTC.Text = dataGridView1.CurrentRow.Cells["TC"].Value.ToString();
            txtNameSurname.Text = dataGridView1.CurrentRow.Cells["NameSurname"].Value.ToString();
            txtTelephone.Text = dataGridView1.CurrentRow.Cells["Telephone"].Value.ToString();
            txtAdress.Text = dataGridView1.CurrentRow.Cells["Adress"].Value.ToString();
            txtEmail.Text = dataGridView1.CurrentRow.Cells["Email"].Value.ToString();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            txtTC.Text = dataGridView1.CurrentRow.Cells["TC"].Value.ToString();
            txtNameSurname.Text = dataGridView1.CurrentRow.Cells["NameSurname"].Value.ToString();
            txtTelephone.Text = dataGridView1.CurrentRow.Cells["Telephone"].Value.ToString();
            txtAdress.Text = dataGridView1.CurrentRow.Cells["Adress"].Value.ToString();
            txtEmail.Text = dataGridView1.CurrentRow.Cells["Email"].Value.ToString();
        }

        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand command = new SqlCommand("update Customer set NameSurname=@NameSurname, Telephone=@Telephone,Adress=@Adress,Email=@Email where TC=@TC", connection);
            command.Parameters.AddWithValue("@TC", txtTC.Text);
            command.Parameters.AddWithValue("@NameSurname", txtNameSurname.Text);
            command.Parameters.AddWithValue("@Telephone", txtTelephone.Text);
            command.Parameters.AddWithValue("@Adress", txtAdress.Text);
            command.Parameters.AddWithValue("@Email", txtEmail.Text);
            command.ExecuteNonQuery();
            connection.Close();
            daset.Tables["Customer"].Clear();
            Show_Registry();
            MessageBox.Show("Customer registry updated");
            foreach (Control item in this.Controls)
            {
                if (item is TextBox)
                {
                    item.Text = "";
                }
            }
        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand command = new SqlCommand("delete from Customer where TC='" + dataGridView1.CurrentRow.Cells["TC"].Value.ToString() + "'", connection);
            command.ExecuteNonQuery();
            connection.Close();
            daset.Tables["Customer"].Clear();
            Show_Registry();
            MessageBox.Show("Registry deleted");
        }

        private void txtTCSearch_TextChanged(object sender, EventArgs e)
        {
            DataTable table = new DataTable();
            connection.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from Customer where TC like '%" + txtTCSearch.Text + "%'", connection);
            adtr.Fill(table);
            dataGridView1.DataSource = table;
            connection.Close(); 
        }

        private void txtTC_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
