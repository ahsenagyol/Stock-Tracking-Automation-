﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stock_Tracking_Otomation
{
    public partial class FrmListSales : Form
    {
        public FrmListSales()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection("Data Source=DESKTOP-43Q01LI;Initial Catalog=Stock_Tracking;Integrated Security=True");
        DataSet daset = new DataSet();

        private void listSales()
        {
            connection.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from Sales", connection);
            adtr.Fill(daset, "Sales");
            dataGridView1.DataSource = daset.Tables["Sales"];

            connection.Close();
        }

        private void FrmListSales_Load(object sender, EventArgs e)
        {
            listSales();
        }
    }
}
