﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Stock_Tracking_Otomation
{
    public partial class FrmCategory : Form
    {
        public FrmCategory()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection("Data Source=DESKTOP-43Q01LI;Initial Catalog=Stock_Tracking;Integrated Security=True");
        bool instance;
        private void Categorycontrol()
        {
            instance = true;
            connection.Open();
            SqlCommand command = new SqlCommand("select *from CategoryInformations",connection);
            SqlDataReader read = command.ExecuteReader();
            while (read.Read())
            {
                if (textBox1.Text==read["Category"].ToString() || textBox1.Text=="")
                {
                    instance = false;
                }
            }
            connection.Close();
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            Categorycontrol();
            if  (instance==true)
            {
                connection.Open();
                SqlCommand command = new SqlCommand("insert into CategoryInformations(Category) values ('" + textBox1.Text + "')", connection);
                command.ExecuteNonQuery();
                connection.Close();
                MessageBox.Show("Added category");
            }
            else
            {
                MessageBox.Show("There is such a category", "Warning");
            }
            textBox1.Text = "";

        }

        private void FrmCategory_Load(object sender, EventArgs e)
        {

        }
    }
}
