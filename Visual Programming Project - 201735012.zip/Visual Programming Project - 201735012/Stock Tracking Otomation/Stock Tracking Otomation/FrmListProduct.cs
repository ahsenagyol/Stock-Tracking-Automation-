﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stock_Tracking_Otomation
{
    public partial class FrmListProduct : Form
    {
        public FrmListProduct()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection("Data Source=DESKTOP-43Q01LI;Initial Catalog=Stock_Tracking;Integrated Security=True");
        DataSet daset = new DataSet();

        private void Categorybring()
        {
            connection.Open();
            SqlCommand command = new SqlCommand("select *from CategoryInformations", connection);
            SqlDataReader read = command.ExecuteReader();
            while (read.Read())
            {
                comboCategory.Items.Add(read["Category"].ToString());
            }
            connection.Close();
        }


        private void btnDelete_Click(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand command = new SqlCommand("delete from Product where BarcodeNo ='" + dataGridView1.CurrentRow.Cells["BarcodeNo"].Value.ToString() + "'", connection);
            command.ExecuteNonQuery();
            connection.Close();
            daset.Tables["Product"].Clear();
            ListProduct();
            MessageBox.Show("Registry deleted");
        }

        private void FrmListProduct_Load(object sender, EventArgs e)
        {
            ListProduct();
            Categorybring();

        }

        private void ListProduct()
        {
            connection.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from Product", connection);
            adtr.Fill(daset, "Product");
            dataGridView1.DataSource = daset.Tables["Product"];
            connection.Close();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            BarcodeNotxt.Text = dataGridView1.CurrentRow.Cells["BarcodeNo"].Value.ToString();
            Categorytxt.Text = dataGridView1.CurrentRow.Cells["Category"].Value.ToString();
            Brandtxt.Text = dataGridView1.CurrentRow.Cells["Brand"].Value.ToString();
            ProductNametxt.Text = dataGridView1.CurrentRow.Cells["ProductName"].Value.ToString();
            Quantitytxt.Text = dataGridView1.CurrentRow.Cells["Quantity"].Value.ToString();
            PurchasePricetxt.Text = dataGridView1.CurrentRow.Cells["PurchasePrice"].Value.ToString();
            SalePricetxt.Text = dataGridView1.CurrentRow.Cells["SalesPrice"].Value.ToString();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand command = new SqlCommand("update Product set ProductName=@ProductName,Quantity=@Quantity,PurchasePrice=@PurchasePrice,SalesPrice=@SalePrice where BarcodeNo=@BarcodeNo",connection);
            command.Parameters.AddWithValue("@BarcodeNo",BarcodeNotxt.Text);
            command.Parameters.AddWithValue("@ProductName", ProductNametxt.Text);
            command.Parameters.AddWithValue("@Quantity", int.Parse(Quantitytxt.Text));
            command.Parameters.AddWithValue("@PurchasePrice", double.Parse(PurchasePricetxt.Text));
            command.Parameters.AddWithValue("@SalesPrice", double.Parse(SalePricetxt.Text));
            command.ExecuteNonQuery();
            connection.Close();
            daset.Tables["Product"].Clear();
            ListProduct();
            MessageBox.Show("Updated");
            foreach (Control item in this.Controls)
            {
                if (item is TextBox)
                {
                    item.Text = "";
                }
            }
        }

        private void btnUpdateBrand_Click(object sender, EventArgs e)
        {
            if (BarcodeNotxt.Text!="")
            {
                connection.Open();
                SqlCommand command = new SqlCommand("update Product set Category=@Category,Brand=@Brand where BarcodeNo=@BarcodeNo", connection);
                command.Parameters.AddWithValue("@BarcodeNo", BarcodeNotxt.Text);
                command.Parameters.AddWithValue("@Category", comboCategory.Text);
                command.Parameters.AddWithValue("@Brand", comboBrand.Text);
                command.ExecuteNonQuery();
                connection.Close();
                MessageBox.Show("Updated");
                daset.Tables["Product"].Clear();
                ListProduct();
            }
            else
            {
                MessageBox.Show("Barcode No not written");
            }

            foreach (Control item in this.Controls)
            {
                if (item is ComboBox)
                {
                    item.Text = "";
                }
            }
        }

        private void comboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBrand.Items.Clear();
            comboBrand.Text = "";
            connection.Open();
            SqlCommand command = new SqlCommand("select *from BrandInformations where Category='" + comboCategory.SelectedItem + "'", connection);
            SqlDataReader read = command.ExecuteReader();
            while (read.Read())
            {
                comboBrand.Items.Add(read["Brand"].ToString());
            }
            connection.Close();
        }

        private void txtSearchBarcodeNo_TextChanged(object sender, EventArgs e)
        {
            DataTable table = new DataTable();
            connection.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from Product where BarcodeNo like '%" + txtSearchBarcodeNo.Text + "%'", connection);
            adtr.Fill(table);
            dataGridView1.DataSource = table;
            connection.Close();
        }
    }
}
