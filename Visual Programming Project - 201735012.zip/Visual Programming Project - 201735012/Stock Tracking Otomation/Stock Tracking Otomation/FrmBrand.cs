﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stock_Tracking_Otomation
{
    public partial class FrmBrand : Form
    {
        public FrmBrand()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection("Data Source=DESKTOP-43Q01LI;Initial Catalog=Stock_Tracking;Integrated Security=True");
        bool instance;
        private void BrandControl()
        {
            instance = true;
            connection.Open();
            SqlCommand command = new SqlCommand("select *from BrandInformations", connection);
            SqlDataReader read = command.ExecuteReader();
            while (read.Read())
            {
                if (comboBox1.Text==read["Category"].ToString() && textBox1.Text == read["Brand"].ToString() || comboBox1.Text=="" || textBox1.Text == "")
                {
                    instance = false;
                }
            }
            connection.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Categorybring()
        {
            connection.Open();
            SqlCommand command = new SqlCommand("select *from CategoryInformations", connection);
            SqlDataReader read = command.ExecuteReader();
            while (read.Read())
            {
                comboBox1.Items.Add(read["Category"].ToString());
            }
            connection.Close();

        }
        private void FrmBrand_Load(object sender, EventArgs e)
        {
            Categorybring();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BrandControl();
            if (instance==true)
            {
                connection.Open();
                SqlCommand command = new SqlCommand("insert into BrandInformations(Category,Brand) values ('" + comboBox1.Text + "','" + textBox1.Text + "')", connection);
                command.ExecuteNonQuery();
                connection.Close();
                MessageBox.Show("Added brand");
            }
            else
            {
                MessageBox.Show("There is such a category and brand", "Warning");
            }


            textBox1.Text = "";
            comboBox1.Text = "";
            MessageBox.Show("Added brand");
        }
    }
}
