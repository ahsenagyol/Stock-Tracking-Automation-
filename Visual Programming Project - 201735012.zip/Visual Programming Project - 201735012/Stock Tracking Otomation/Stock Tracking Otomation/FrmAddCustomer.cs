﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Stock_Tracking_Otomation
{
    public partial class FrmAddCustomer : Form
    {
        public FrmAddCustomer()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection("Data Source=DESKTOP-43Q01LI;Initial Catalog=Stock_Tracking;Integrated Security=True");

        private void FrmAddCustomer_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand command = new SqlCommand("insert into customer(TC,NameSurname,Telephone,Adress,Email) values(@TC,@NameSurname,@Telephone,@Adress,@Email)  ", connection);
            command.Parameters.AddWithValue("@TC", txtTC.Text);
            command.Parameters.AddWithValue("@NameSurname", txtNameSurname.Text);
            command.Parameters.AddWithValue("@Telephone", txtTelephone.Text);
            command.Parameters.AddWithValue("@Adress", txtAdress.Text);
            command.Parameters.AddWithValue("@Email", txtEmail.Text);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Customer registry added");
            foreach (Control item in this.Controls)
            {
                if (item is TextBox)
                {
                    item.Text = "";
                }
            }

        }

        private void FrmAddCustomer_Load_1(object sender, EventArgs e)
        {

        }
    }
}
